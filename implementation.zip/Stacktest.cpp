#include <iostream>
#include "stack.h"


int main() {
    Stack myStack;
    std::cout << "Size: " << myStack.size() << std::endl;
    myStack.push(1);
    myStack.print();
    myStack.push(2);
    myStack.print();
    myStack.push(3);
    std::cout << "Size: " << myStack.size() << std::endl;
    myStack.print();

    std::cout << "Top element: " << myStack.peek() << std::endl;

    myStack.pop();
    myStack.print();
    std::cout << "Top element after pop: " << myStack.peek() << std::endl;
    myStack.pop();
    myStack.print();
    //myStack.pop();
    //myStack.print();
    return 0;
}
