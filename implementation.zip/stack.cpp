#include "stack.h"
#include <stdexcept>
#include <iostream>

//constructer
Stack::Stack() {
	count = 0;
	top = nullptr;
}

Stack::~Stack() {
	while (!isEmpty()) {
		pop();
	}
}

void Stack::push(int val) {
	Node* newtop = new Node(val);
	newtop->next = top;
	this->top = newtop;
	this->count++;
}

int Stack::pop() {
	if (!isEmpty()) {
		Node* prevtop = this->top;
		int val = prevtop->val;
		this->top = prevtop->next;
		this->count--;
		delete prevtop;
		return val;
	}
}

int Stack::peek() const{
	if (this->count == 0) {
		throw std::runtime_error("Stack is empty");
	}
	return this->top->val;
}

bool Stack::isEmpty() {
	return this->top == nullptr;
}

int Stack::size() {
	return this->count;
}

void Stack::print() {
	if (this->count == 0) {
		std::cout << "stack is empty" << std::endl;
		return;
	}
	Node* curr = this->top; 
	std::cout << "TOP->" << std::flush;
	while (curr) {
		std::cout << curr->val << "->" << std::flush;
		curr = curr->next;
	}
	std::cout << "-|" << std::endl;
}


