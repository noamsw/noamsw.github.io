#ifndef COUNTER_H
#define COUNTER_H


// a node class, implemented fully to be used as well
class Node {
public:
    int val;      // The value stored in the node
    Node* next;   // A pointer to the next node

    // Constructor to initialize the node with a value
    Node(int value) : val(value), next(nullptr) {}

    // Destructor (not always necessary, but helpful for cleaning up memory)
    ~Node() {
        // The destructor can be used to clean up resources when the node is no longer needed.
    }
};


class Stack {
public:
    // Constructor
    Stack();
    //destructor
    ~Stack();
    // Member functions
    // a method which adds a single element to the top of the stack
    void push(int val);
    // a method which removes the topmost element from the stack
    int pop();
    // a method which returns the topmost element of the stack, without removal
    int peek() const;
    // a method which returns the number of elements currently in the stack
    int size();
    // a method that checks if the stack is empty
    bool isEmpty();
    // a method that prints the stack, leaving it unchanged
    void print();

private:
    int count;
    Node* top;

};

#endif
