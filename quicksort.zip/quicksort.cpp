#include <iostream>
#include <vector>

int partition(std::vector<int>& arr, int start, int end) {
	int pivot = arr[end];
	int i = start - 1;
	for (int j = start; j < end; j++) {
		if (arr[j] < pivot) {
			i++;
			std::swap(arr[i], arr[j]);
		}
	}
	std::swap(arr[i + 1], arr[end]);
	return i + 1;
}

void quickSort(std::vector<int>& arr, int start, int end) {
	if (start < end) {
		int pivot = partition(arr, start, end);
		quickSort(arr, start, pivot - 1);
		quickSort(arr, pivot + 1, end);
	}
}


int main() {
	std::vector<int> arr = { 32,21,1,5,3,76,33,0,12 };
	int n = arr.size();

	quickSort(arr, 0, n - 1);
	
	std::cout << "Sorted Array: ";
	for (int num : arr) {
		std::cout << num << " ";
	}
}