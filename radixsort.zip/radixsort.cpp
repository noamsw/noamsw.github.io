#include <iostream>
#include <vector>

int findMax(std::vector<int>& arr) {
	int max = arr[0];
	for (int num : arr) {
		if (num > max) {
			max = num;
		}
	}
	return max;
}

void radixSort(std::vector<int>& arr) {
	int max = findMax(arr);
	int exp = 1;
	int n = arr.size();
	while (max / exp) {
		std::vector<int> counts(10, 0);
		std::vector<int> output(10, 0);
		for (int i = 0; i < n; i++) {
			counts[(arr[i] / exp) % 10]++;
		}

		for (int j = 1; j < 10; j++) {
			counts[j] += counts[j - 1];
		}
		for (int i = n - 1; i >= 0; i--) {
			output[counts[(arr[i] / exp) % 10] - 1] = arr[i];
			counts[(arr[i] / exp) % 10]--;
		}

		for (int i = 0; i < n; i++) {
			arr[i] = output[i];
		}

		exp *= 10;

	}
}


int main() {
	std::vector<int> arr = { 190, 0, 75, 80, 802, 24, 2, 66 };
	int n = arr.size();

	radixSort(arr);

	std::cout << "Sorted array: ";
	for (int num : arr) {
		std::cout << num << " ";
	}

	return 0;
}