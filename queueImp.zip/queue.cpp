#include "queue.h"
#include <stdexcept>
#include <iostream>

//constructer
Queue::Queue() {
	count = 0;
	head = nullptr;
	tail = nullptr;
}

Queue::~Queue() {
	while (!isEmpty()) {
		dequeue();
	}
}

void Queue::enqueue(int val) {
	Node* newtail = new Node(val);
	if (tail) {
		tail->next = newtail;
	}
	if (!head) {
		head = newtail;
	}
	tail = newtail;
	this->count++;
}

int Queue::dequeue() {
	if (!isEmpty()) {
		int val = head->val;
		Node* prevhead = head;
		head = head->next;
		if (!head) {
			tail = nullptr;
		}
		this->count--;
		delete prevhead;
		return val;
	}
}

int Queue::peek() const{
	if (this->count == 0) {
		throw std::runtime_error("Queue is empty");
	}
	return this->head->val;
}

bool Queue::isEmpty() {
	return this->head == nullptr;
}

int Queue::size() {
	return this->count;
}

void Queue::print() {
	if (this->count == 0) {
		std::cout << "stack is empty" << std::endl;
		return;
	}
	Node* curr = this->head; 
	std::cout << "HEAD->" << std::flush;
	while (curr) {
		std::cout << curr->val << "->" << std::flush;
		curr = curr->next;
	}
	std::cout << "-|" << std::endl;
}


