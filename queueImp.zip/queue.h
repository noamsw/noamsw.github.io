#ifndef QUEUE_H
#define QUEUE_H


// a node class, implemented fully to be used as well
class Node {
public:
    int val;      // The value stored in the node
    Node* next;   // A pointer to the next node

    // Constructor to initialize the node with a value
    Node(int value) : val(value), next(nullptr) {}

    // Destructor (not always necessary, but helpful for cleaning up memory)
    ~Node() {
        // The destructor can be used to clean up resources when the node is no longer needed.
    }
};


class Queue {
public:
    // Constructor
    Queue();
    //destructor
    ~Queue();
    // Member functions
    // a method which adds a single element to the back of the queue
    void enqueue(int val);
    // a method which removes a single element from the front of the queue
    int dequeue();
    // a method which returns the element at the front of the queue, without removal
    int peek() const;
    // a method which returns the number of elements currently in the queue
    int size();
    // a method which returns true if the queue is empty 
    bool isEmpty();
    // a method that prints the queue, leaving it unchanged
    void print();

private:
    int count;
    Node* head;
    Node* tail;

};

#endif
