#include <iostream>
#include "queue.h"


int main() {
    Queue myQueue;
    std::cout << "Size: " << myQueue.size() << std::endl;
    myQueue.enqueue(1);
    myQueue.print();
    myQueue.enqueue(2);
    myQueue.print();
    myQueue.enqueue(3);
    std::cout << "Size: " << myQueue.size() << std::endl;
    myQueue.print();

    std::cout << "Top element: " << myQueue.peek() << std::endl;

    myQueue.dequeue();
    myQueue.print();
    std::cout << "Top element after dequeue: " << myQueue.peek() << std::endl;
    myQueue.dequeue();
    myQueue.print();
    myQueue.dequeue();
    myQueue.print();
    myQueue.enqueue(4);
    myQueue.enqueue(4);
    myQueue.dequeue();
    myQueue.print();
    return 0;
}
